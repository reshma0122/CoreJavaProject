package com.itv.core.eventmgmt;

import java.time.LocalDate;

public class Event {
	
	
	private int e_id;
	private String e_name;
	private LocalDate e_date;
	private String e_location;
	private String e_status;
	
	public Event(int e_id, String e_name, LocalDate e_date, String e_location, String e_status) {

		this.e_id = e_id;
		this.e_name = e_name;
		this.e_date = e_date;
		this.e_location = e_location;
		this.e_status = e_status;
	}

	public int getE_id() {
		return e_id;
	}

	public void setE_id(int e_id) {
		this.e_id = e_id;
	}

	public String getE_name() {
		return e_name;
	}

	public void setE_name(String e_name) {
		this.e_name = e_name;
	}

	public LocalDate getE_date() {
		return e_date;
	}

	public void setE_date(LocalDate e_date) {
		this.e_date = e_date;
	}

	public String getE_location() {
		return e_location;
	}

	public void setE_location(String e_location) {
		this.e_location = e_location;
	}

	public String getE_status() {
		return e_status;
	}

	public void setE_status(String e_status) {
		this.e_status = e_status;
	}

	@Override
	public String toString() {
		return "Event [e_id=" + e_id + ", e_name=" + e_name + ", e_date=" + e_date + ", e_location=" + e_location
				+ ", e_status=" + e_status + "]";
	}


	
	
	
}	
