package com.itv.core.eventmgmt;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class EventServiceImpl implements EventService {

	List<Event> events = new ArrayList<>();
	List<Customers> customers = new ArrayList<>();
	private int eventId = 1;
	private int custId = 1;

	@Override
	public void addEvent(String name, LocalDate date, String location, String status) {
		Event addevent = new Event(eventId, name, date, location, status);
		events.add(addevent);
		eventId++;
		System.out.println("Event added successfully.");
	}

	public void listEvents() {

		if (events.isEmpty()) {
			System.out.println("No events available.");
			return;
		} else {
			System.out.println("Events Details:-");
			for (int i = 0; i < events.size(); i++) {
				Event listevents = events.get(i);
				System.out.println(listevents);
			}
		}
	}

	@Override
	public void getEventById(int event_id) {
		// TODO Auto-generated method stub
		for (int i = 0; i < events.size(); i++) {
			Event eventbyid = events.get(i);
			if(eventbyid.getE_id()== event_id) {
			System.out.println(eventbyid);
			}
		}
	}
	
	@Override
	public void registgerCustomerDtl(String cname, String cemail, int eventid) {
		boolean found = false;
		for (int i = 0; i < events.size(); i++) {
			Event e = events.get(i);
			if (e.getE_id() == eventid) {
				found = true;
			}
		}

		if (!found) {
			System.out.println("Invalid event ID.");
			return;
		}

		Customers c = new Customers(custId, cname, cemail, eventid);
		custId++;
		customers.add(c);
		System.out.println("Customer registered.");

	}

	@Override
	public void customerslist() {
		if (customers.isEmpty()) {
			System.out.println("No Customers registered.");
			return;
		}
		System.out.println("Customer List");
		for (int i = 0; i < customers.size(); i++) {
			Customers p = customers.get(i);

			System.out.println(p);
		}
	}

	@Override
	public void updateEventStatus(int event_id) {
		LocalDate date = LocalDate.now();

		for (int i = 0; i < events.size(); i++) {
			Event e = events.get(i);
			LocalDate eventDate = e.getE_date();

			if (eventDate.isBefore(date) && e.getE_id() == event_id) {
				e.setE_status("completed");
				System.out.println("Updated susccesfully.");
				System.out.println(e);
			}
			
		}

	}

	@Override
	public void removeEventdtl(int event_id) {
		// TODO Auto-generated method stub
		events.remove(event_id);
		System.out.println("Remove Event deatils.");
	}


}
