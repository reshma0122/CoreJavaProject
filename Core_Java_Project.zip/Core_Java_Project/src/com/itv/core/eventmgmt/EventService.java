package com.itv.core.eventmgmt;

import java.time.LocalDate;

public interface EventService {

	public void addEvent(String name, LocalDate date, String location, String status);
	public void listEvents();
	public void getEventById(int event_id);
	public void registgerCustomerDtl(String cname, String cemail, int eventid);
	public void customerslist();
	public void updateEventStatus(int event_id);
	public void removeEventdtl(int event_id);
}
