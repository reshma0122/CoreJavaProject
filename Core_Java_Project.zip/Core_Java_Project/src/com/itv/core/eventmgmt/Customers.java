package com.itv.core.eventmgmt;

public class Customers {


	private int cust_id;
	private String cust_name;
	private String cust_email;
	private int event_id;
	
	public Customers(int cust_id, String cust_name, String cust_email, int event_id) {
		this.cust_id=cust_id;
		this.cust_name = cust_name;
		this.cust_email = cust_email;
		this.event_id = event_id;
	}

	public int getCust_id() {
		return cust_id;
	}

	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}

	public String getCust_name() {
		return cust_name;
	}

	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}

	public String getCust_email() {
		return cust_email;
	}

	public void setCust_email(String cust_email) {
		this.cust_email = cust_email;
	}

	public int getEvent_id() {
		return event_id;
	}

	public void setEvent_id(int event_id) {
		this.event_id = event_id;
	}

	@Override
	public String toString() {
		return "Customer [cust_id=" + cust_id + ", cust_name=" + cust_name + ", cust_email=" + cust_email
				+ ", event_id=" + event_id + "]";
	}

}
