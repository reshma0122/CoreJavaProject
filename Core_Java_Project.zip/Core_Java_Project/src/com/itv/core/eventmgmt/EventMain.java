package com.itv.core.eventmgmt;

import java.time.LocalDate;
import java.util.Scanner;

public class EventMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Scanner scanner = new Scanner(System.in);
        EventServiceImpl eventsImpl = new EventServiceImpl();
        int choice = 0;

        while (choice != 7) {
            System.out.println("\n--- Event Management System ---");
            System.out.println("1. Add Event");
            System.out.println("2. View All Events");
            System.out.println("3. View Event By ID");
            System.out.println("4. Register Customer Details");
            System.out.println("5. Update Event Status");
            System.out.println("6. Remove Event");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 
            
            switch (choice) {
                case 1:
                    System.out.print("Enter event name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter event date: ");
                    String date = scanner.nextLine();
                    System.out.print("Enter event location: ");
                    String location = scanner.nextLine();
                    System.out.print("Enter event status: ");
                    String status = scanner.nextLine();
                    eventsImpl.addEvent(name, LocalDate.parse(date), location, status);
                    break;
                case 2:
                    eventsImpl.listEvents();
                    break;
                case 3:
                	System.out.print("Enter event id: ");
                    int e_id = scanner.nextInt();
                	eventsImpl.getEventById(e_id);
                    break;
                case 4:
                    System.out.print("Enter Customer name: ");
                    String cname = scanner.nextLine();
                    System.out.print("Enter email: ");
                    String email = scanner.nextLine();
                    System.out.print("Enter event ID to register:");
                    int eid = scanner.nextInt();
                    scanner.nextLine();
                    eventsImpl.registgerCustomerDtl(cname, email, eid);
                    System.out.print("Register Customer Details: ");
                    eventsImpl.customerslist();
                    break;
                case 5:
                	System.out.print("Enter event id: ");
                    int etid = scanner.nextInt();
                    eventsImpl.updateEventStatus(etid);
                    break;
                case 6:
                	System.out.print("Enter Removing event id: ");
                    int removeeventid = scanner.nextInt();
                    eventsImpl.removeEventdtl(removeeventid);
                    break;
                case 7:
                    System.out.println("Exiting system...");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }

        scanner.close();
    }

}
